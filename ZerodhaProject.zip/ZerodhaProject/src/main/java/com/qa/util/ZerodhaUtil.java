package com.qa.util;

public class ZerodhaUtil extends ZerodhaTestBase{

	public ZerodhaUtil() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}
	
	static int PAGE_LOAD_TIMEOUT = 20;
	static int IMPLICIT_WAIT = 30;

}
